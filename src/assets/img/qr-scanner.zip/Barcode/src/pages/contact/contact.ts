import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { BarcodeScanner } from '@ionic-native/barcode-scanner';

@Component({
  selector: 'page-contact',
  templateUrl: 'contact.html'
})
export class ContactPage {

  qrData = null;
  createdCode = null;
  scannedCode = null;

  constructor(public navCtrl: NavController,private barcodeScanner: BarcodeScanner) {

  }

  createCode() {
    this.createdCode = this.qrData;
  }

}
